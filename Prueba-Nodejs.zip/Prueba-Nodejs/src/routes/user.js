const express = require('express');
const userSchema = require('../models/user')
const routes = express.Router();


//create user
routes.post("/user", (req, res) => {
    //console.log('hola');
    const user = userSchema(req.body);
    user.save().then((data) => res.json(data)).catch((err) => res.json({ message: err }));
});
//get all user form database
routes.get("/user", (req, res) => {
    //  console.log("hola");
    userSchema.find()
        .then((data) => res.json(data))
        .catch((err) => res.json({ message: err }));
});

// get user by id
routes.get("/user/:id", (req, res) => {
    //console.log("hola");
    const { id } = req.params;
    userSchema.findById(id)
        .then((data) => res.json(data))
        .catch((err) => res.json({ message: err }));
});

//get less than 30

routes.get("/user/lessthan30",(req, res) => {
    serSchema.find((err, userSchema) => {    
        userSchema.forEach(function(usr,i){
             if(usr.age < 30){
               res.json(data);           
             }
         });
         })

});
//update
routes.put("/user/:id", (req, res) => {
    //console.log("hola");
    const { id } = req.params;
    const { name, age } = req.body;
    userSchema.updateOne({ _id: id }, { $set: { name, age } })
        .then((data) => res.json(data))
        .catch((err) => res.json({ message: err }));
});

routes.delete("/user/:id", (req, res) => {
    console.log("hola");
    userSchema.deleteOne({ "_id": req.params.id })
        .then((data) => res.json(data))
        .catch((err) => res.json({ message: err }));
});


module.exports = routes;