const moongose = require('mongoose');

const userSchema = moongose.Schema({
    _id:{type:String},
    index:{type:Number },
    guid:{type:String},
    age:{type: Number},
    name:{type:String},
    gender:{type:String},
    company:{type:String},
    email:{type:String},
    phone:{type:String},
});

module.exports = User = moongose.model('user',userSchema);