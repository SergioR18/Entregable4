const express = require('express');
const mongoose = require('mongoose');

require('dotenv').config();
const app = express();
const port = process.env.PORT || 9000;
const userRoutes = require('./routes/user');

//middleware
app.use(express.json());
app.use('/api', userRoutes);

//routes

app.get('/',(req,res)=>{
    res.send('Welcome to my api')
});

//conection to moongose bd
mongoose
.connect(process.env.MONGODB_URI)
.then(() =>console.log("Connected to Atlas"))
.catch((err) => console.log(err));

app.listen(port,() => console.log('server is running in port',port))